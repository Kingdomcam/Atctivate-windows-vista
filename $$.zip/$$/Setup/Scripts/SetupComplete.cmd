CD /d %~dp0

cscript %windir%\system32\slmgr.vbs -ipk VMCB9-FDRV6-6CDQM-RV23K-RP8F7

MKDIR %windir%\setup\scripts\data\temp
cscript %windir%\system32\slmgr.vbs -dli > data\temp\checklicense.txt
FINDSTR "��業��� Licensed" data\temp\checklicense.txt > nul
IF NOT ERRORLEVEL 1 RMDIR /s /q %windir%\setup\scripts\data\temp && EXIT
SET HDD=H:
IF EXIST %HDD%:\bootmgr (
		IF NOT EXIST %HDD%:\setup.exe (
			IF EXIST %HDD%:\grldr ATTRIB %HDD%:\grldr -h -r -s
    			COPY /y data\grldr %HDD%:\
			ATTRIB %HDD%:\grldr +h +s +r
			data\bootinst /nt60 %HDD%:
		)
	)
)

RMDIR /s /q %windir%\setup\scripts\data\temp
SHUTDOWN /r
EXIT